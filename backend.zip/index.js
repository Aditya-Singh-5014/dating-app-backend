// index.js
const server = require("./src/server");
module.exports = server;
