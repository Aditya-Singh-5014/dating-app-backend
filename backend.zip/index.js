// index.js
const server = require("./api/server");
module.exports = server;
