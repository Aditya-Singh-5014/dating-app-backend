const User = require("../models/User");

exports.getMatches = async (req, res) => {
  const userId = req.user.uid;
  try {
    const user = await User.findOne({ uid: userId });
    if (!user) {
      return res.status(404).json({ error: "User not found" });
    }

    const matches = await User.find({
      gender:
        user.genderPreference !== "Both"
          ? user.genderPreference
          : { $ne: user.gender },
      age: { $gte: user.minAgePreference, $lte: user.maxAgePreference },
      interests: { $in: user.interests },
      _id: { $ne: user._id },
    });

    res.json(matches);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};
